#!/usr/bin/env python
# coding: utf-8

def get_ESM2_650M_scores_from_WT_logits(
    df,
    seq_col: str,
    evo_col: str,
    WT: str,
    *,
    model,
    tokenizer,
    wt_logits=None,
    batch_size: int = 2048,
    require_same_length: bool = True,
):
    """
    FAST pseudo-perplexity scoring using precomputed WT logits.

    Given wt_logits[i, :] = logits at residue i when WT has residue i masked,
    compute for each sequence x (aligned to WT positions 0..L-1):

      lp_i(x) = log P(token(x_i) | WT with i masked)
      sum_nll = -sum_i lp_i(x)
      mean_nll = sum_nll / L
      pseudo_ppl = exp(mean_nll)

    Notes:
      - No model forward passes inside this function.
      - Requires tokenizer encoding to produce residue token IDs aligned to WT residue positions.
      - Handles EOS properly by excluding eos_id from residue mask.

    Writes:
      - df[evo_col], df[evo_col+"_mean_nll"], df[evo_col+"_sum_nll"]
      - df["neg_ESM2_650M_log_probs_norm_WT"] = -(mean_nll - WT_mean_nll)
    """
    import numpy as np
    import pandas as pd
    import torch
    import torch.nn.functional as F

    device = next(model.parameters()).device if hasattr(model, "parameters") else torch.device("cpu")

    def clean(s: str) -> str:
        return s.replace(" ", "").strip().upper() if isinstance(s, str) else ""

    def to_aa_spaced(s: str) -> str:
        return " ".join(list(s))

    WT = clean(WT)
    if WT == "":
        raise ValueError("WT must be a non-empty string for WT-logits scoring.")

    if wt_logits is None:
        wt_logits = get_logits_for_all_positions(model=model, WT=WT, tokenizer=tokenizer)

    if not torch.is_tensor(wt_logits):
        wt_logits = torch.as_tensor(wt_logits)

    wt_logits = wt_logits.to(device)
    L, V = wt_logits.shape
    if L != len(WT):
        raise ValueError(f"wt_logits has L={L} but len(WT)={len(WT)}; expected L == len(WT).")

    wt_logp = F.log_softmax(wt_logits, dim=-1)  # (L, V)

    pad_id = tokenizer.pad_token_id
    cls_id = tokenizer.cls_token_id
    sep_id = tokenizer.sep_token_id
    eos_id = getattr(tokenizer, "eos_token_id", None)

    # Determine WT residue token positions (token-space indices)
    wt_enc = tokenizer(
        to_aa_spaced(WT),
        return_tensors="pt",
        add_special_tokens=True,
        padding=False,
        truncation=False,
    )
    wt_input_ids = wt_enc["input_ids"].to(device)[0]        # (T,)
    wt_attn = wt_enc["attention_mask"].to(device)[0].bool() # (T,)

    wt_score_mask = wt_attn.clone()
    for sid in (pad_id, cls_id, sep_id, eos_id):
        if sid is not None:
            wt_score_mask &= (wt_input_ids != sid)

    wt_resid_pos = torch.nonzero(wt_score_mask, as_tuple=False).view(-1)  # (L,)
    if wt_resid_pos.numel() != L:
        raise ValueError(
            f"Tokenizer residue-token count for WT ({wt_resid_pos.numel()}) != L ({L}). "
            "WT/logits indexing mismatch."
        )

    # WT mean_nll under WT logits (for normalization)
    wt_res_ids = wt_input_ids[wt_resid_pos]  # (L,)
    wt_lp = wt_logp[torch.arange(L, device=device), wt_res_ids]  # (L,)
    wt_mean_nll = float((-wt_lp).mean().item())

    # Ensure WT exists in df (optional)
    col_u = df[seq_col].astype(str).map(clean)
    if not (col_u == WT).any():
        df = pd.concat([df, pd.DataFrame([{seq_col: WT}])], ignore_index=True)

    # init outputs
    df[evo_col] = np.nan
    df[evo_col + "_mean_nll"] = np.nan
    df[evo_col + "_sum_nll"] = np.nan
    df["neg_ESM2_650M_log_probs_norm_WT"] = np.nan

    seqs = df[seq_col].astype(str).map(clean).tolist()
    valid = [(i, s) for i, s in enumerate(seqs) if s != ""]

    for start in range(0, len(valid), batch_size):
        chunk = valid[start : start + batch_size]
        idxs = [i for i, _ in chunk]
        s_chunk = [s for _, s in chunk]

        if require_same_length:
            keep = [len(s) == L for s in s_chunk]
            if not any(keep):
                continue
            idxs = [idxs[j] for j, k in enumerate(keep) if k]
            s_chunk = [s_chunk[j] for j, k in enumerate(keep) if k]

        enc = tokenizer(
            [to_aa_spaced(s) for s in s_chunk],
            return_tensors="pt",
            add_special_tokens=True,
            padding=True,
            truncation=False,
        )
        input_ids = enc["input_ids"].to(device)              # (B, Tpad)
        attn = enc["attention_mask"].to(device).bool()       # (B, Tpad)

        score_mask = attn.clone()
        for sid in (pad_id, cls_id, sep_id, eos_id):
            if sid is not None:
                score_mask &= (input_ids != sid)

        if wt_resid_pos.max().item() >= input_ids.shape[1]:
            continue  # cannot align token positions

        residues = input_ids[:, wt_resid_pos]         # (B, L) token ids at residue positions
        residues_mask = score_mask[:, wt_resid_pos]   # (B, L)

        ok_rows = residues_mask.all(dim=1)
        if ok_rows.sum().item() == 0:
            continue

        residues = residues[ok_rows]  # (Bok, L)
        idxs_ok = np.asarray(idxs)[ok_rows.detach().cpu().numpy()]

        # Broadcast wt_logp to batch and gather token log-probs
        wt_logp_b = wt_logp.unsqueeze(0).expand(residues.size(0), -1, -1)  # (Bok, L, V)
        lp = wt_logp_b.gather(2, residues.unsqueeze(-1)).squeeze(-1)       # (Bok, L)

        nll = -lp
        sum_nll = nll.sum(dim=1)
        mean_nll = nll.mean(dim=1)
        pseudo_ppl = torch.exp(mean_nll)

        df.loc[idxs_ok, evo_col + "_sum_nll"] = sum_nll.detach().cpu().numpy()
        df.loc[idxs_ok, evo_col + "_mean_nll"] = mean_nll.detach().cpu().numpy()
        df.loc[idxs_ok, evo_col] = pseudo_ppl.detach().cpu().numpy()
        df.loc[idxs_ok, "neg_ESM2_650M_log_probs_norm_WT"] = -1.0 * (
            df.loc[idxs_ok, evo_col + "_mean_nll"].astype(float) - wt_mean_nll
        )

    return df

def get_logits_for_all_positions(model, WT, tokenizer, model_identifier=None):
    """
    Precompute WT-context logits at each residue position i by masking that position once.

    HF-consistent:
      - Tokenize WT as space-separated AAs
      - Identify residue token positions in token space (exclude specials/pad/eos)
      - Mask via token IDs (not by editing the string)
      - Extract logits at the masked token position

    Returns:
      wt_logits: (L, Vocab)
        L = len(WT) residues, Vocab = tokenizer vocab size (ESM2 ~33)
    """
    import torch

    device = next(model.parameters()).device
    WT = WT.replace(" ", "").strip().upper()
    L = len(WT)

    mask_id = tokenizer.mask_token_id
    pad_id = tokenizer.pad_token_id
    cls_id = tokenizer.cls_token_id
    sep_id = tokenizer.sep_token_id
    eos_id = getattr(tokenizer, "eos_token_id", None)

    if mask_id is None:
        raise ValueError("Tokenizer has no mask_token_id.")

    def to_aa_spaced(s: str) -> str:
        return " ".join(list(s))

    # tokenize WT once
    wt_enc = tokenizer(
        to_aa_spaced(WT),
        return_tensors="pt",
        add_special_tokens=True,
        padding=False,
        truncation=False,
    )
    wt_enc = {k: v.to(device) for k, v in wt_enc.items()}
    wt_input_ids = wt_enc["input_ids"][0]          # (T,)
    wt_attn = wt_enc["attention_mask"][0].bool()   # (T,)

    # residue token positions (exclude specials/pad/eos)
    wt_score_mask = wt_attn.clone()
    for sid in (pad_id, cls_id, sep_id, eos_id):
        if sid is not None:
            wt_score_mask &= (wt_input_ids != sid)

    wt_resid_pos = torch.nonzero(wt_score_mask, as_tuple=False).view(-1)  # (L_token,)
    if wt_resid_pos.numel() != L:
        raise ValueError(
            f"Tokenizer residue-token count ({wt_resid_pos.numel()}) != len(WT) ({L}). "
            "WT formatting/tokenization mismatch."
        )

    all_logits = []
    with torch.no_grad():
        for j in range(L):
            p = int(wt_resid_pos[j].item())  # token position for residue j

            masked_ids = wt_enc["input_ids"].clone()  # (1, T)
            masked_ids[0, p] = mask_id

            out = model(input_ids=masked_ids, attention_mask=wt_enc["attention_mask"])
            logits = out.logits  # (1, T, Vocab)

            all_logits.append(logits[0, p].detach())  # (Vocab,)

    return torch.stack(all_logits, dim=0)  # (L, Vocab)

def get_ESM2_650M_scores(
    df,
    seq_col: str,
    evo_col: str,
    WT: str,
    data_path=None,
    label_cols=None,
    protein=None,
    batch_size: int = 4,
    masked_batch_size: int = 8,
    hf_model_name: str = "facebook/esm2_t33_650M_UR50D",
):
    """
    TRUE pseudo-perplexity via masked pseudo-likelihood:
      For each sequence and each residue token position i:
        mask i -> forward -> -log P(true token at i)

    This is the slow reference implementation (model forward per masked position).

    Writes:
      - df[evo_col] = exp(mean_nll)
      - df[evo_col+"_mean_nll"], df[evo_col+"_sum_nll"]
      - df["neg_ESM2_650M_log_probs_norm_WT"] or df["neg_ESM2_650M_log_probs"]
    """
    import numpy as np
    import pandas as pd
    import torch
    import torch.nn.functional as F
    from transformers import AutoTokenizer, AutoModelForMaskedLM

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    tokenizer = AutoTokenizer.from_pretrained(hf_model_name, do_lower_case=False)
    model = AutoModelForMaskedLM.from_pretrained(hf_model_name).to(device).eval()

    pad_id = tokenizer.pad_token_id
    mask_id = tokenizer.mask_token_id
    cls_id = tokenizer.cls_token_id
    sep_id = tokenizer.sep_token_id
    eos_id = getattr(tokenizer, "eos_token_id", None)

    if mask_id is None:
        raise ValueError("Tokenizer has no mask_token_id.")

    def clean(s: str) -> str:
        return s.replace(" ", "").strip().upper() if isinstance(s, str) else ""

    def to_aa_spaced(s: str) -> str:
        return " ".join(list(s))

    # ensure WT exists (optional)
    WT = clean(WT)
    if WT:
        col_u = df[seq_col].astype(str).map(clean)
        if not (col_u == WT).any():
            df = pd.concat([df, pd.DataFrame([{seq_col: WT}])], ignore_index=True)

    # init outputs
    df[evo_col] = np.nan
    df[evo_col + "_mean_nll"] = np.nan
    df[evo_col + "_sum_nll"] = np.nan

    # valid sequences
    valid = [(i, clean(s)) for i, s in enumerate(df[seq_col].astype(str)) if clean(s) != ""]
    print(f"[INFO] Running ESM2-650M pseudo-perplexity (true masked PLL) for {len(valid)} sequences...")

    for start in range(0, len(valid), batch_size):
        chunk = valid[start : start + batch_size]
        idxs = [i for i, _ in chunk]
        seqs = [s for _, s in chunk]

        enc = tokenizer(
            [to_aa_spaced(s) for s in seqs],
            return_tensors="pt",
            padding=True,
            truncation=False,
            add_special_tokens=True,
        )
        input_ids = enc["input_ids"].to(device)            # (B, T)
        attention_mask = enc["attention_mask"].to(device)  # (B, T)

        B, T = input_ids.shape

        score_mask = attention_mask.bool()
        for sid in (pad_id, cls_id, sep_id, eos_id):
            if sid is not None:
                score_mask &= (input_ids != sid)

        pairs = []
        for b in range(B):
            pos_list = torch.nonzero(score_mask[b], as_tuple=False).view(-1).tolist()
            pairs.extend([(b, p) for p in pos_list])

        if len(pairs) == 0:
            continue

        sum_nll = torch.zeros(B, device=device, dtype=torch.float32)
        count = torch.zeros(B, device=device, dtype=torch.float32)

        for k in range(0, len(pairs), masked_batch_size):
            sub = pairs[k : k + masked_batch_size]
            Mb = len(sub)

            b_list = [b for (b, _) in sub]
            p_list = [p for (_, p) in sub]
            pos_idx = torch.tensor(p_list, device=device, dtype=torch.long)

            masked_ids = input_ids[b_list].clone()            # (Mb, T)
            masked_attn = attention_mask[b_list].clone()      # (Mb, T)
            masked_ids[torch.arange(Mb, device=device), pos_idx] = mask_id

            with torch.no_grad():
                out = model(input_ids=masked_ids, attention_mask=masked_attn)
                logits = out.logits  # (Mb, T, V)

            true_tok = input_ids[b_list, pos_idx]  # (Mb,)

            lp = F.log_softmax(
                logits[torch.arange(Mb, device=device), pos_idx, :],
                dim=-1,
            )  # (Mb, V)

            nll = -lp[torch.arange(Mb, device=device), true_tok]  # (Mb,)

            b_idx = torch.tensor(b_list, device=device, dtype=torch.long)
            sum_nll.index_add_(0, b_idx, nll)
            count.index_add_(0, b_idx, torch.ones_like(nll))

        mean_nll = sum_nll / count.clamp_min(1.0)
        pseudo_ppl = torch.exp(mean_nll)

        df.loc[idxs, evo_col + "_sum_nll"] = sum_nll.detach().cpu().numpy()
        df.loc[idxs, evo_col + "_mean_nll"] = mean_nll.detach().cpu().numpy()
        df.loc[idxs, evo_col] = pseudo_ppl.detach().cpu().numpy()

    # WT normalization
    if WT:
        wt_mask = df[seq_col].astype(str).map(clean).eq(WT)
        wt_mean_nll = float(df.loc[wt_mask, evo_col + "_mean_nll"].astype(float).mean())
        df["neg_ESM2_650M_log_probs_norm_WT"] = -1.0 * (df[evo_col + "_mean_nll"] - wt_mean_nll)
    else:
        df["neg_ESM2_650M_log_probs"] = -1.0 * df[evo_col + "_mean_nll"]

    return df




