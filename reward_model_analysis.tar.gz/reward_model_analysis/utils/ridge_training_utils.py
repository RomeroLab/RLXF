
# import packages
import os
import uuid
import shutil
import subprocess
import numpy as np
import pandas as pd

def split_sequence(df, seq_col="sequence"):
    seq_df = df[seq_col].apply(list).apply(pd.Series)
    seq_df.columns = [f"pos_{i}" for i in range(seq_df.shape[1])]
    expanded_df = pd.concat([df.drop(columns=[seq_col]), seq_df], axis=1)
    return expanded_df, seq_df.shape[1]

def top10_recall_function(y_true, y_pred):
    """Compute Top-10% Recall between predicted and true values."""
    if len(y_true) == 0:
        return np.nan
    n_top = max(1, int(0.1 * len(y_true)))
    top_true_idx = np.argsort(y_true)[-n_top:]
    top_pred_idx = np.argsort(y_pred)[-n_top:]
    overlap = len(set(top_true_idx) & set(top_pred_idx))
    return overlap / n_top

def ridge_score_batch(seqs, evo_scores, evo_multiplier, ridge_model):
    """
    seqs       : list of sequences
    evo_scores : np.array (raw PPO/TranceptEVE scores)
    """
    df = pd.DataFrame({"sequence": seqs})
    expanded_df, L = split_sequence(df, seq_col="sequence")
    expanded_df["evo_scaled"] = evo_scores * evo_multiplier
    preds = ridge_model.predict(expanded_df)
    return np.asarray(preds, dtype=np.float32)

def trancepteve_scores_batch(seqs, config):
    """
    Standalone TranceptEVE batch-scoring function for Jupyter notebook.
    
    Args:
        seqs (list[str]): sequences to score
        config (dict): contains all required parameters,
            see keys below.

    Returns:
        np.ndarray shape (N,) with avg_score values
    """

    if len(seqs) == 0:
        return np.array([], dtype=np.float32)

    # Unpack config dictionary
    protein        = config["protein"]
    WT             = config["WT"]
    model_identifier = config["model_identifier"]
    logger_version   = config["logger_version"]
    tranception_root = config["tranception_root"]
    trancept_checkpoint = config["trancept_checkpoint"]
    msa_base       = config["msa_base"]
    weights_base   = config["weights_base"]
    eve_model_folder   = config["eve_model_folder"]
    eve_model_params   = config["eve_model_params"]
    trancept_random_seeds = config["trancept_random_seeds"]
    trancept_theta       = config["trancept_theta"]
    trancept_inference_type = config["trancept_inference_type"]
    trancept_num_samples = config["trancept_num_samples"]
    trancept_scoring_window = config["trancept_scoring_window"]
    trancept_manual_msa_weight = config["trancept_manual_msa_weight"]
    trancept_manual_eve_weight = config["trancept_manual_eve_weight"]

    # --------------------------------------
    # Mutation-string helper (port from class)
    # --------------------------------------
    def mutation_string(wt, seq):
        muts = []
        for i, (a, b) in enumerate(zip(wt, seq), start=1):
            if a != b:
                muts.append(f"{a}{i}{b}")
        return ":".join(muts) if muts else ""

    # --------------------------------------
    # 1. Temporary folder + variants CSV
    # --------------------------------------
    run_id = uuid.uuid4().hex[:8]
    base_log_dir = f"./logs/PPO_{protein}_{model_identifier}/version_{logger_version}"
    results_dir = os.path.join(base_log_dir, f"trancepteve_step_{run_id}")
    os.makedirs(results_dir, exist_ok=True)
    scores_dir = os.path.join(results_dir, "calculating_evo_scores")
    if os.path.exists(scores_dir):
        shutil.rmtree(scores_dir)
    os.makedirs(scores_dir, exist_ok=True)

    variants_path = os.path.join(results_dir, f"{protein}_variants_ppo_{run_id}.csv")

    records = []
    for s in seqs:
        records.append({"mutated_sequence": s, "mutant": mutation_string(WT, s)})
    variants_df = pd.DataFrame(records)
    variants_df.to_csv(variants_path, index=False)

    # --------------------------------------
    # 2. Write TranceptEVE scoring script
    # --------------------------------------
    random_seeds_str = " ".join(str(s) for s in trancept_random_seeds)
    sh_path = os.path.join(results_dir, f"score_trancepteve_{protein}_{run_id}.sh")

    script = f"""#!/bin/bash
set -e

protein="{protein}"
theta={trancept_theta}
checkpoint="{trancept_checkpoint}"
msa_base="{msa_base}"
weights_base="{weights_base}"
output_base="{results_dir}"

inference_time_retrieval_type="{trancept_inference_type}"
EVE_num_samples_log_proba={trancept_num_samples}
scoring_window="{trancept_scoring_window}"
EVE_model_folder="{eve_model_folder}"
EVE_model_parameters_location="{eve_model_params}"
random_seeds=({random_seeds_str})
EVE_seeds_str="${{random_seeds[@]}}"

echo "[INFO] Scoring $protein variants with TranceptEVE ..."

wt_seq=$(grep -v ">" ${{msa_base}}/${{protein}}.fa | tr -d '\\n')
len=${{#wt_seq}}

python -u {tranception_root}/score_trancepteve.py \\
    --checkpoint $checkpoint \\
    --target_seq $wt_seq \\
    --DMS_file_name $(basename "{variants_path}") \\
    --MSA_filename $protein.a2m \\
    --MSA_weight_file_name $protein"_theta_"${{theta}}".npy" \\
    --MSA_start 1 \\
    --MSA_end $len \\
    --MSA_threshold_sequence_frac_gaps 1.0 \\
    --MSA_threshold_focus_cols_frac_gaps 1.0 \\
    --DMS_data_folder "{results_dir}/" \\
    --output_scores_folder "{results_dir}/scores" \\
    --scoring_window $scoring_window \\
    --inference_time_retrieval_type $inference_time_retrieval_type \\
    --retrieval_weights_manual \\
    --retrieval_inference_MSA_weight {trancept_manual_msa_weight} \\
    --retrieval_inference_EVE_weight {trancept_manual_eve_weight} \\
    --MSA_folder ${{msa_base}}/out/{protein}/align \\
    --MSA_weights_folder $weights_base \\
    --EVE_model_folder $EVE_model_folder \\
    --EVE_num_samples_log_proba $EVE_num_samples_log_proba \\
    --EVE_model_parameters_location $EVE_model_parameters_location \\
    --EVE_seeds $EVE_seeds_str \\
    --EVE_recalibrate_probas

echo "[DONE] Finished scoring $protein with TranceptEVE"
"""

    with open(sh_path, "w") as f:
        f.write(script)
    os.chmod(sh_path, 0o755)

    # --------------------------------------
    # 3. Run the script
    # --------------------------------------
    trancept_env = config["trancept_env"]  # e.g. "tranception_env"
    subprocess.run(
        ["conda", "run", "-n", trancept_env, "bash", sh_path],
        check=True
    )

    # --------------------------------------
    # 4. Read output scores (no merge, keep duplicates)
    # --------------------------------------
    scored_path = os.path.join(results_dir, "scores", os.path.basename(variants_path))

    if not os.path.exists(scored_path):
        raise FileNotFoundError(f"TranceptEVE output not found at {scored_path}")

    print(f"[DEBUG] Expecting scored_path = {scored_path}")
    scored_df = pd.read_csv(scored_path)

    print(f"[DEBUG] variants_df length = {len(variants_df)}")
    print(f"[DEBUG] scored_df length   = {len(scored_df)}")

    if "avg_score" not in scored_df.columns:
        raise KeyError("'avg_score' column not found in TranceptEVE output")

    # Check lengths first
    if len(scored_df) != len(variants_df):
        # Helpful debug if this ever happens
        print("[ERROR] length mismatch between variants_df and scored_df!")
        print("[DEBUG] n_unique variants_df:",
              variants_df[["mutated_sequence", "mutant"]].drop_duplicates().shape[0])
        print("[DEBUG] n_unique scored_df:",
              scored_df[["mutated_sequence", "mutant"]].drop_duplicates().shape[0])
        raise ValueError("TranceptEVE output length does not match input variants length.")

    # Optional sanity check: ensure rows line up
    same_mut_seq = np.array_equal(
        variants_df["mutated_sequence"].values,
        scored_df["mutated_sequence"].values,
    )
    same_mut_str = np.array_equal(
        variants_df["mutant"].values,
        scored_df["mutant"].values,
    )
    if not (same_mut_seq and same_mut_str):
        print("[WARN] (mutated_sequence, mutant) order mismatch between variants_df and scored_df.")
        # You can still proceed by trusting the positional match, or raise:
        # raise ValueError("Order mismatch between TranceptEVE input and output.")

    evo_scores = scored_df["avg_score"].to_numpy(dtype=np.float32)
    print(f"[DEBUG] evo_scores shape = {evo_scores.shape}")

    return evo_scores



