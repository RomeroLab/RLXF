import os, glob, yaml, pickle
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from joblib import dump
from scipy.stats import pearsonr, spearmanr
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold
import seaborn as sns

from utils.ridge_training_utils import split_sequence, top10_recall_function

# -----------------------------
# Configuration
# -----------------------------
protein = "ube4b" # options: ['avgfp', 'bgl3', 'creilov', 'gb1', 'pab1', 'ube4b']
label_col = "functional_score"
evo_col = "avg_score_trancepteve"
data_path = f"./{protein}/data/processed_SeqFxnDataset.pkl"
split_dir = f"./{protein}/data"
results_root = f"./{protein}/results"
os.makedirs(results_root, exist_ok=True)

# -----------------------------
# Load processed dataset
# -----------------------------
df = pd.read_pickle(data_path)

# -----------------------------
# Iterate over all splits
# -----------------------------
split_paths = sorted(glob.glob(f"{split_dir}/low_N_{protein}_*.pkl"))
print(f"[INFO] Found {len(split_paths)} split files for {protein}")

# Collect metrics
records = []
cv_records = []
for split_path in split_paths:
    split_name = os.path.basename(split_path)
    print(f"\n[INFO] Processing split: {split_name}")

    # Parse name parts
    parts = split_name.replace(".pkl", "").split("_")
    split_type = "mut1" if "mut1" in parts else "any"
    size = int(next((p for p in parts if p.isdigit()), "0"))
    version = parts[-1].replace("v", "") if "v" in parts[-1] else "0"

    # Output directory
    results_dir = f"{results_root}/{split_name.replace('.pkl','')}"
    os.makedirs(results_dir, exist_ok=True)
    
    # Output directory
    results_dir = f"{results_root}/{split_name.replace('.pkl','')}"
    os.makedirs(results_dir, exist_ok=True)

    # -----------------------------
    # Load split indices
    # -----------------------------
    with open(split_path, "rb") as f:
        train_idx, _, test_idx = pickle.load(f)

    df_train = df.loc[train_idx].reset_index(drop=True)
    df_train = df_train.dropna(subset=[label_col])
    df_test = df.loc[test_idx].reset_index(drop=True)

    # -----------------------------
    # Ridge regression with 5-fold CV on df_train
    # -----------------------------
    evo_reg_coeffs = [1e-3, 1e-4, 5e-5, 1e-5]
    onehot_reg_coeff = 1.0
    ridge_alpha = 1.0

    # determine number of folds
    if len(df_train) > 5:
        cv_scores = []
        n_splits = min(5, len(df_train))
        kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

        for evo_reg_coeff in evo_reg_coeffs:
            fold_spearmans, fold_pearsons, fold_top10s = [], [], []

            for train_idx_cv, val_idx_cv in kf.split(df_train):
                train_cv = df_train.iloc[train_idx_cv]
                val_cv = df_train.iloc[val_idx_cv]
                # --- Prepare splits ---
                X_train_cv, y_train_cv = train_cv[["sequence", evo_col]], train_cv[label_col]
                X_val_cv, y_val_cv = val_cv[["sequence", evo_col]], val_cv[label_col]
                # --- Expand sequences ---
                X_train_cv_split, seq_len = split_sequence(X_train_cv)
                X_val_cv_split, _ = split_sequence(X_val_cv)
                pos_cols = [f"pos_{i}" for i in range(seq_len)]
                # --- Scale evo feature according to regularization ratio ---
                evo_scale = np.sqrt(onehot_reg_coeff / evo_reg_coeff)
                X_train_cv_split["evo_scaled"] = X_train_cv_split[evo_col] * evo_scale
                X_val_cv_split["evo_scaled"] = X_val_cv_split[evo_col] * evo_scale
                # --- Ridge regression pipeline ---
                preproc = ColumnTransformer([
                    ("seq_onehot", OneHotEncoder(handle_unknown="ignore"), pos_cols),
                    ("evo", "passthrough", ["evo_scaled"])
                ])
                model = Pipeline([
                    ("features", preproc),
                    ("ridge", Ridge(alpha=ridge_alpha))
                ])

                # --- Train and validate ---
                model.fit(X_train_cv_split, y_train_cv)
                y_pred_cv = model.predict(X_val_cv_split)
                
                # --- Compute correlation metrics ---
                if len(np.unique(y_val_cv)) > 1 and len(np.unique(y_pred_cv)) > 1:
                    sp, _ = spearmanr(y_val_cv, y_pred_cv)
                    pr, _ = pearsonr(y_val_cv, y_pred_cv)
                else:
                    sp, pr = np.nan, np.nan
                t10 = top10_recall_function(y_val_cv.to_numpy(), y_pred_cv)
                fold_spearmans.append(sp)
                fold_pearsons.append(pr)
                fold_top10s.append(t10)

            # average across folds
            cv_scores.append({
                "evo_reg_coeff": evo_reg_coeff,
                "mean_spearman": np.nanmean(fold_spearmans),
                "mean_pearson": np.nanmean(fold_pearsons),
                "mean_top10": np.nanmean(fold_top10s)
            })

        # --- Select best evo_reg_coeff ---
        cv_df = pd.DataFrame(cv_scores)

        # --- Select best evo_reg_coeff based on Spearman ---
        if cv_df["mean_spearman"].notna().any():
            best_idx = cv_df.loc[cv_df["mean_spearman"].notna(), "mean_spearman"].idxmax()
            best_evo_reg = float(cv_df.loc[best_idx, "evo_reg_coeff"])
            best_top10 = float(cv_df.loc[best_idx, "mean_top10"])
            print(f"[CV] Best evo_reg_coeff = {best_evo_reg:.1e} (Spearman={cv_df.loc[best_idx, 'mean_spearman']:.3f}, Top10={best_top10:.3f})")
        elif cv_df["mean_pearson"].notna().any():
            best_idx = cv_df.loc[cv_df["mean_pearson"].notna(), "mean_pearson"].idxmax()
            best_evo_reg = float(cv_df.loc[best_idx, "evo_reg_coeff"])
            best_top10 = float(cv_df.loc[best_idx, "mean_top10"])
        else:
            best_evo_reg = 1e-5
            best_top10 = np.nan
            print(f"[CV] All CV metrics NaN; defaulting evo_reg_coeff = {best_evo_reg:.1e}")
    
    else:
        best_evo_reg = 1e-5
        best_top10 = np.nan
        print(f"[Too few training examples for CV] Selected evo_reg_coeff to maximize evoluence influence")

    # -----------------------------
    # Save CV metrics for best evo_reg_coeff
    # -----------------------------
    cv_summary_path = f"{results_dir}/{protein}_ridge_cv_metrics.csv"
    cv_df.to_csv(cv_summary_path, index=False)

    cv_best_metrics = {
        "protein": protein,
        "split_name": split_name,
        "split_type": split_type,
        "size": size,
        "version": int(version),
        "best_evo_reg": best_evo_reg,
        "cv_spearman": float(cv_df.loc[best_idx, "mean_spearman"]),
        "cv_pearson": float(cv_df.loc[best_idx, "mean_pearson"]),
        "cv_top10": best_top10,
        "train_rows": len(df_train),
        "test_rows": len(df_test)
    }
    cv_records.append(cv_best_metrics)
    print(f"[SAVED] CV metrics → {cv_summary_path}")

    # -----------------------------
    # Prepare inputs and outputs
    # -----------------------------
    X_train, y_train = df_train[["sequence", evo_col]], df_train[label_col]
    X_test, y_test = df_test[["sequence", evo_col]], df_test[label_col]
    X_train_split, seq_len = split_sequence(X_train)
    X_test_split, _ = split_sequence(X_test)
    pos_cols = [f"pos_{i}" for i in range(seq_len)]
    
    # -----------------------------
    # Ridge regression pipeline
    # -----------------------------
    evo_reg_coeff = best_evo_reg
    evo_scale = np.sqrt(onehot_reg_coeff / evo_reg_coeff)
    X_train_split["evo_scaled"] = X_train_split[evo_col] * evo_scale
    X_test_split["evo_scaled"] = X_test_split[evo_col] * evo_scale
    preproc = ColumnTransformer([
        ("seq_onehot", OneHotEncoder(handle_unknown="ignore"), pos_cols),
        ("evo", "passthrough", ["evo_scaled"])
    ])
    model = Pipeline([
        ("features", preproc),
        ("ridge", Ridge(alpha=1.0))
    ])
    model.fit(X_train_split, y_train)
    model_path = f"{results_dir}/{protein}_ridge_model.joblib"
    dump(model, model_path)
#     print(f"[SAVED] Model → {model_path}")

    # -----------------------------
    # Predict
    # -----------------------------
    y_pred = model.predict(X_test_split)
    results = pd.DataFrame({
        "sequence": df_test["sequence"],
        "true_label": y_test,
        "pred_label": y_pred
    })
    results.to_csv(f"{results_dir}/{protein}_test_predictions.csv", index=False)

    # -----------------------------
    # Evaluate
    # -----------------------------
    def safe_corr(y_true, y_pred):
        if np.all(y_true == y_true.iloc[0]) or np.all(y_pred == y_pred[0]):
            return np.nan, np.nan
        else:
            return pearsonr(y_true, y_pred)
    pearson_r, pearson_p = safe_corr(results["true_label"], results["pred_label"])
    spearman_r, spearman_p = safe_corr(results["true_label"].rank(), results["pred_label"].rank())
    k = max(1, int(0.10 * len(results)))
    true_top = results.nlargest(k, "true_label").index
    pred_top = results.nlargest(k, "pred_label").index
    top10_recall = len(set(true_top).intersection(set(pred_top))) / len(true_top)
#     print(f"[RESULTS] r={pearson_r:.3f}, ρ={spearman_r:.3f}, top10={top10_recall:.3f}")

    # -----------------------------
    # Coefficients
    # -----------------------------
    ridge = model.named_steps["ridge"]
    preproc = model.named_steps["features"]
    seq_feature_names = preproc.named_transformers_["seq_onehot"].get_feature_names_out(pos_cols)
    coefs = ridge.coef_.ravel()
    seq_coefs = coefs[:-1]
    evo_coef_effective = coefs[-1] * evo_scale
    onehot_encoder = preproc.named_transformers_["seq_onehot"]
    categories = onehot_encoder.categories_
    weights_per_pos = np.array([np.abs(seq_coefs[offset:offset + len(c)]).mean()
                                for offset, c in zip(np.cumsum([0]+[len(x) for x in categories[:-1]]), categories)])

    # -----------------------------
    # Plot per-position mean |weight|
    # -----------------------------
    plt.figure(figsize=(10, 3))
    positions = np.arange(1, len(weights_per_pos) + 1)
    plt.plot(positions, weights_per_pos, lw=1.2, color="black", label="Mean |Weight| per Position")
    plt.xlabel("Residue Position (1-indexed)", fontsize=12)
    plt.ylabel("Mean |Weight| per Position", fontsize=12)
    plt.title(f"{protein.upper()} – Ridge Coefficients per Position", fontsize=13)
    plt.xticks(ticks=np.linspace(1, len(weights_per_pos), num=min(len(weights_per_pos), 10), dtype=int))
    plt.legend(frameon=False, loc="upper right", fontsize=10)
    plt.tight_layout()
    pos_fig_path_png = f"{results_dir}/{protein}_ridge_coefficients_per_position.png"
    pos_fig_path_svg = f"{results_dir}/{protein}_ridge_coefficients_per_position.svg"
    plt.savefig(pos_fig_path_png, dpi=300)
    plt.savefig(pos_fig_path_svg, dpi=300)
    plt.close()
#     print(f"[SAVED] Per-position coefficient plot → {pos_fig_path_png}")

    # -----------------------------
    # Save coefficients
    # -----------------------------
    coef_df = pd.DataFrame({
        "feature_type": ["sequence"] * len(weights_per_pos) + ["evolutionary"],
        "position": list(range(1, len(weights_per_pos) + 1)) + ["NA"],
        "mean_abs_weight": np.concatenate([weights_per_pos, [evo_coef_effective]])
    })
    coef_df.to_csv(f"{results_dir}/{protein}_ridge_coefficients.csv", index=False)

    # -----------------------------
    # Save per-position amino acid weights
    # -----------------------------
    aa_weight_records = []
    offset = 0
    for pos_idx, aa_list in enumerate(categories):
        n_aas = len(aa_list)
        aa_coefs = seq_coefs[offset:offset + n_aas]
        for aa, coef in zip(aa_list, aa_coefs):
            aa_weight_records.append({
                "position": pos_idx + 1,  # 1-indexed
                "amino_acid": aa,
                "weight": coef,
                "abs_weight": abs(coef)
            })
        offset += n_aas
    aa_weight_df = pd.DataFrame(aa_weight_records)
    aa_weight_pivot = aa_weight_df.pivot_table(
        index="amino_acid", columns="position", values="weight", fill_value=0.0
    ).sort_index()

    # Save both raw and absolute weights
    aa_weight_df.to_csv(f"{results_dir}/{protein}_ridge_aa_weights_long.csv", index=False)
    aa_weight_pivot.to_csv(f"{results_dir}/{protein}_ridge_aa_weights_matrix.csv")
    # print(f"[SAVED] Amino acid weight tables → {results_dir}/{protein}_ridge_aa_weights_matrix.csv")

    # -----------------------------
    # Plot and save heatmap of amino acid weights
    # -----------------------------
    plt.figure(figsize=(max(8, len(aa_weight_pivot.columns) / 10), 6))
    sns.heatmap(
        aa_weight_pivot,
        cmap="coolwarm",        # diverging colormap centered on 0
        center=0.0,
        linewidths=0.3,
        cbar_kws={"label": "Weight"},
    )
    plt.title(f"{protein.upper()} – Ridge Coefficients by Amino Acid and Position", fontsize=13)
    plt.xlabel("Residue Position (1-indexed)", fontsize=12)
    plt.ylabel("Amino Acid", fontsize=12)
    plt.tight_layout()
    heatmap_png = f"{results_dir}/{protein}_ridge_aa_weight_heatmap.png"
    heatmap_svg = f"{results_dir}/{protein}_ridge_aa_weight_heatmap.svg"
    plt.savefig(heatmap_png, dpi=300)
    plt.savefig(heatmap_svg, dpi=300)
    plt.close()
#     print(f"[SAVED] Amino acid weight heatmap → {heatmap_png}")

    # -----------------------------
    # Save relative influence
    # -----------------------------
    total_seq_weight = np.sum(np.abs(seq_coefs))
    total_evo_weight = abs(evo_coef_effective)
    denom = total_seq_weight + total_evo_weight
    ratio = total_seq_weight / denom if denom != 0 else np.nan
    influence_df = pd.DataFrame([{
        "protein": protein,
        "split_name": split_name,
        "total_seq_weight": total_seq_weight,
        "total_evo_weight": total_evo_weight,
        "relative_influence_evo": ratio
    }])
    influence_df.to_csv(f"{results_dir}/{protein}_ridge_relative_influence.csv", index=False)

    # -----------------------------
    # Save summary metadata
    # -----------------------------
    run_metadata = {
        "protein": protein,
        "split_name": split_name,
        "train_rows": len(df_train),
        "test_rows": len(df_test),
        "metrics": {
            "pearson_r": float(pearson_r),
            "spearman_r": float(spearman_r),
            "top10_recall": float(top10_recall)
        },
        "relative_influence_evo": float(ratio),
        "evo_scale": float(evo_scale),
        "ridge_alpha": 1.0
    }
    with open(f"{results_dir}/{protein}_ridge_metadata.yaml", "w") as f:
        yaml.dump(run_metadata, f, sort_keys=False)
        
    # Store results
    records.append({
        "protein": protein,
        "split_type": split_type,
        "size": size,
        "version": int(version),
        "pearson_r": pearson_r,
        "spearman_r": spearman_r,
        "top10_recall": top10_recall,
        "train_rows": len(df_train),
        "test_rows": len(df_test)
    })
#     print(f"[DONE] Results saved in → {results_dir}")
print(f"[DONE] Finished training models")

# -----------------------------
# Aggregate across versions
# -----------------------------
metrics_df = pd.DataFrame(records)

# Load influence CSVs to merge with metrics
influence_records = []
for split_path in split_paths:
    split_name = os.path.basename(split_path).replace(".pkl", "")
    influence_path = f"{results_root}/{split_name}/{protein}_ridge_relative_influence.csv"
    if os.path.exists(influence_path):
        df_inf = pd.read_csv(influence_path)
        df_inf["split_type"] = "mut1" if "mut1" in split_name else "any"
        df_inf["size"] = int(next((p for p in split_name.split("_") if p.isdigit()), "0"))
        influence_records.append(df_inf)

if influence_records:
    influence_df = pd.concat(influence_records, ignore_index=True)
else:
    influence_df = pd.DataFrame(columns=["protein", "split_name", "split_type", "size", "relative_influence_evo"])

# Merge metrics + influence
metrics_df = metrics_df.merge(influence_df[["split_name", "relative_influence_evo", "split_type", "size"]],
                              on=["split_type", "size"], how="left")

# Aggregate
agg_df = (
    metrics_df
    .groupby(["split_type", "size"])
    .agg({
        "pearson_r": ["mean", "std"],
        "spearman_r": ["mean", "std"],
        "top10_recall": ["mean", "std"],
        "relative_influence_evo": ["mean", "std"]
    })
    .reset_index()
)

# Flatten columns
agg_df.columns = ["split_type", "size",
                  "pearson_mean", "pearson_std",
                  "spearman_mean", "spearman_std",
                  "top10_mean", "top10_std",
                  "influence_mean", "influence_std"]

# Replace NaN stds (e.g., single split) with 0
agg_df = agg_df.fillna(0)

# Save
agg_csv_path = f"{results_root}/{protein}_ridge_summary_metrics.csv"
agg_df.to_csv(agg_csv_path, index=False)
# print(f"[SAVED] Aggregated metrics → {agg_csv_path}")

# -----------------------------
# Load baselines
# -----------------------------
baseline_csv = f"./figures/TranceptEVE/metrics/{protein}_metrics.csv"
if os.path.exists(baseline_csv):
    base_df = pd.read_csv(baseline_csv)
    baselines = {
        "Tranception": dict(zip(base_df["Model"], base_df["Spearman"])).get("Tranception", np.nan),
        "EVE": dict(zip(base_df["Model"], base_df["Spearman"])).get("EVE", np.nan),
        "TranceptEVE": dict(zip(base_df["Model"], base_df["Spearman"])).get("TranceptEVE", np.nan),
    }
#     print(f"[INFO] Loaded baselines → {baseline_csv}")
else:
    baselines = {"Tranception": np.nan, "EVE": np.nan, "TranceptEVE": np.nan}
    print(f"[WARN] Baseline file not found for {protein}")

# -----------------------------
# Add high_N_reward_models baselines
# -----------------------------
highN_baselines = {
    "creilov":  {"Spearman": 0.933, "Pearson": 0.940},
    "avgfp":    {"Spearman": 0.691, "Pearson": 0.774},
    "bgl3":     {"Spearman": 0.990, "Pearson": 1.000},
    "gb1":      {"Spearman": 0.972, "Pearson": 0.972},
    "pab1":     {"Spearman": 0.922, "Pearson": 0.930},
    "ube4b":    {"Spearman": 0.471, "Pearson": 0.573},
}

highN = highN_baselines.get(protein.lower(), {"Spearman": np.nan, "Pearson": np.nan})

# Add to baseline dictionary for plotting
baselines["High-N Reward Model"] = highN["Spearman"]

# -----------------------------
# Plot summary (3 panels + influence)
# -----------------------------
fig, axes = plt.subplots(1, 4, figsize=(16, 4), sharex=True)
colors = {"mut1": "#D55E00", "any": "#0072B2"}
baseline_styles = {
    "Tranception": "gray",
    "EVE": "darkgreen",
    "TranceptEVE": "blue",
    "High-N Reward Model": "red",
}

# Performance metrics
for split_type, group_df in agg_df.groupby("split_type"):
    x = group_df["size"]
    for ax, metric, std, title in zip(
        axes[:3],
        ["spearman_mean", "pearson_mean", "top10_mean"],
        ["spearman_std", "pearson_std", "top10_std"],
        ["Spearman ρ", "Pearson r", "Top 10% Recall"]
    ):
        ax.plot(x, group_df[metric], marker="o", lw=1.5,
                label=split_type, color=colors[split_type])
        ax.fill_between(x,
                        group_df[metric] - group_df[std],
                        group_df[metric] + group_df[std],
                        alpha=0.2, color=colors[split_type])
        ax.set_xlabel("Training Size")
        ax.set_ylabel(title)

        # --- Add baseline horizontal lines ---
        for name, val in baselines.items():
            if not np.isnan(val):
                if "Spearman" in title and name == "High-N Reward Model":
                    y_val = highN["Spearman"]
                elif "Pearson" in title and name == "High-N Reward Model":
                    y_val = highN["Pearson"]
                elif "Top" in title:
                    continue  # skip for recall plot
                else:
                    y_val = val

                if not np.isnan(y_val):
                    ax.axhline(y=y_val, color=baseline_styles[name],
                               linestyle="--", lw=1, label=f"{name} baseline")

# Relative influence subplot
for split_type, group_df in agg_df.groupby("split_type"):
    x = group_df["size"]
    axes[3].plot(x, group_df["influence_mean"], marker="o", lw=1.5,
                 color=colors[split_type], label=split_type)
    axes[3].fill_between(x,
                         group_df["influence_mean"] - group_df["influence_std"],
                         group_df["influence_mean"] + group_df["influence_std"],
                         alpha=0.2, color=colors[split_type])
axes[3].set_xlabel("Training Size")
axes[3].set_ylabel("Relative Sequence Influence (0–1)")

# --- Collect all unique handles/labels for a combined legend ---
handles, labels = [], []
for ax in axes:
    h, l = ax.get_legend_handles_labels()
    handles.extend(h)
    labels.extend(l)
unique = dict(zip(labels, handles))

# --- Add a single horizontal legend below all plots ---
fig.legend(unique.values(), unique.keys(),
           loc="lower center", ncol=6, frameon=False, fontsize=10)
plt.tight_layout(rect=[0, 0.05, 1, 0.96])  # leave space for legend
summary_fig_path = f"{results_root}/{protein}_ridge_performance_summary_plus_influence.png"
plt.savefig(summary_fig_path, dpi=300)
summary_fig_path = f"{results_root}/{protein}_ridge_performance_summary_plus_influence.svg"
plt.savefig(summary_fig_path, dpi=300)
plt.close()
# print(f"[SAVED] Summary plot → {summary_fig_path}")

# -----------------------------
# Subset summary (size ≤ 250)
# -----------------------------
subset_df = agg_df[agg_df["size"] <= 250]

fig, axes = plt.subplots(1, 4, figsize=(16, 4), sharex=True)
colors = {"mut1": "#D55E00", "any": "#0072B2"}

for split_type, group_df in subset_df.groupby("split_type"):
    x = group_df["size"]
    for ax, metric, std, title in zip(
        axes[:3],
        ["spearman_mean", "pearson_mean", "top10_mean"],
        ["spearman_std", "pearson_std", "top10_std"],
        ["Spearman ρ", "Pearson r", "Top 10% Recall"]
    ):
        ax.plot(x, group_df[metric], marker="o", lw=1.5,
                label=split_type, color=colors[split_type])
        ax.fill_between(x,
                        group_df[metric] - group_df[std],
                        group_df[metric] + group_df[std],
                        alpha=0.2, color=colors[split_type])
        ax.set_xlabel("Training Size")
        ax.set_ylabel(title)

        # --- Baselines ---
        for name, val in baselines.items():
            if "Spearman" in title and name == "High-N Reward Model":
                y_val = highN["Spearman"]
            elif "Pearson" in title and name == "High-N Reward Model":
                y_val = highN["Pearson"]
            elif "Top" in title:
                continue
            else:
                y_val = val
            if not np.isnan(y_val):
                ax.axhline(y=y_val, color=baseline_styles[name],
                           linestyle="--", lw=1, label=f"{name} baseline")

# Influence subplot
for split_type, group_df in subset_df.groupby("split_type"):
    x = group_df["size"]
    axes[3].plot(x, group_df["influence_mean"], marker="o", lw=1.5,
                 color=colors[split_type], label=split_type)
    axes[3].fill_between(x,
                         group_df["influence_mean"] - group_df["influence_std"],
                         group_df["influence_mean"] + group_df["influence_std"],
                         alpha=0.2, color=colors[split_type])
axes[3].set_xlabel("Training Size")
axes[3].set_ylabel("Relative Sequence Influence (0–1)")

# Legend & save
handles, labels = [], []
for ax in axes:
    h, l = ax.get_legend_handles_labels()
    handles.extend(h)
    labels.extend(l)
unique = dict(zip(labels, handles))

fig.legend(unique.values(), unique.keys(),
           loc="lower center", ncol=6, frameon=False, fontsize=10)
plt.tight_layout(rect=[0, 0.05, 1, 0.96])

subset_fig_path = f"{results_root}/{protein}_ridge_performance_summary_plus_influence_subset250.png"
plt.savefig(subset_fig_path, dpi=300)
subset_fig_path = f"{results_root}/{protein}_ridge_performance_summary_plus_influence_subset250.svg"
plt.savefig(subset_fig_path, dpi=300)
plt.close()

# -----------------------------
# Aggregate across versions
# -----------------------------

cv_metrics_df = pd.DataFrame(cv_records)
cv_agg_df = (
    cv_metrics_df
    .groupby(["split_type", "size"])
    .agg({
        "cv_pearson": ["mean", "std"],
        "cv_spearman": ["mean", "std"],
        "cv_top10": ["mean", "std"],
    })
    .reset_index()
)
cv_agg_df.columns = [
    "split_type", "size",
    "pearson_mean", "pearson_std",
    "spearman_mean", "spearman_std",
    "top10_mean", "top10_std",
]

# Replace NaN stds (e.g., single split) with 0
cv_agg_df = cv_agg_df.fillna(0)

# Save
cv_agg_csv_path = f"{results_root}/{protein}_ridge_summary_cv_metrics.csv"
cv_agg_df.to_csv(cv_agg_csv_path, index=False)
# print(f"[SAVED] Aggregated metrics → {agg_csv_path}")

# -----------------------------
# Load baselines
# -----------------------------
baseline_csv = f"./figures/TranceptEVE/metrics/{protein}_metrics.csv"
if os.path.exists(baseline_csv):
    base_df = pd.read_csv(baseline_csv)
    baselines = {
        "Tranception": dict(zip(base_df["Model"], base_df["Spearman"])).get("Tranception", np.nan),
        "EVE": dict(zip(base_df["Model"], base_df["Spearman"])).get("EVE", np.nan),
        "TranceptEVE": dict(zip(base_df["Model"], base_df["Spearman"])).get("TranceptEVE", np.nan),
    }
#     print(f"[INFO] Loaded baselines → {baseline_csv}")
else:
    baselines = {"Tranception": np.nan, "EVE": np.nan, "TranceptEVE": np.nan}
    print(f"[WARN] Baseline file not found for {protein}")

# -----------------------------
# Add high_N_reward_models baselines
# -----------------------------
highN_baselines = {
    "creilov":  {"Spearman": 0.933, "Pearson": 0.940},
    "avgfp":    {"Spearman": 0.691, "Pearson": 0.774},
    "bgl3":     {"Spearman": 0.990, "Pearson": 1.000},
    "gb1":      {"Spearman": 0.972, "Pearson": 0.972},
    "pab1":     {"Spearman": 0.922, "Pearson": 0.930},
    "ube4b":    {"Spearman": 0.471, "Pearson": 0.573},
}

highN = highN_baselines.get(protein.lower(), {"Spearman": np.nan, "Pearson": np.nan})

# Add to baseline dictionary for plotting
baselines["High-N Reward Model"] = highN["Spearman"]

# -----------------------------
# Plot summary (3 panels + influence)
# -----------------------------
fig, axes = plt.subplots(1, 3, figsize=(16, 3), sharex=True)
colors = {"mut1": "#D55E00", "any": "#0072B2"}
baseline_styles = {
    "Tranception": "gray",
    "EVE": "darkgreen",
    "TranceptEVE": "blue",
    "High-N Reward Model": "red",
}

# Performance metrics
for split_type, group_df in cv_agg_df.groupby("split_type"):
    x = group_df["size"]
    for ax, metric, std, title in zip(
        axes[:3],
        ["spearman_mean", "pearson_mean", "top10_mean"],
        ["spearman_std", "pearson_std", "top10_std"],
        ["Spearman ρ", "Pearson r", "Top 10% Recall"]
    ):
        ax.plot(x, group_df[metric], marker="o", lw=1.5,
                label=split_type, color=colors[split_type])
        ax.fill_between(x,
                        group_df[metric] - group_df[std],
                        group_df[metric] + group_df[std],
                        alpha=0.2, color=colors[split_type])
        ax.set_xlabel("Training Size")
        ax.set_ylabel(title)

        # --- Add baseline horizontal lines ---
        for name, val in baselines.items():
            if not np.isnan(val):
                if "Spearman" in title and name == "High-N Reward Model":
                    y_val = highN["Spearman"]
                elif "Pearson" in title and name == "High-N Reward Model":
                    y_val = highN["Pearson"]
                elif "Top" in title:
                    continue  # skip for recall plot
                else:
                    y_val = val

                if not np.isnan(y_val):
                    ax.axhline(y=y_val, color=baseline_styles[name],
                               linestyle="--", lw=1, label=f"{name} baseline")

# --- Collect all unique handles/labels for a combined legend ---
handles, labels = [], []
for ax in axes:
    h, l = ax.get_legend_handles_labels()
    handles.extend(h)
    labels.extend(l)
unique = dict(zip(labels, handles))

# --- Add a single horizontal legend below all plots ---
fig.legend(unique.values(), unique.keys(),
           loc="lower center", ncol=6, frameon=False, fontsize=10)
plt.tight_layout(rect=[0, 0.05, 1, 0.96])  # leave space for legend
summary_fig_path = f"{results_root}/{protein}_ridge_performance_summary_cv.png"
plt.savefig(summary_fig_path, dpi=300)
summary_fig_path = f"{results_root}/{protein}_ridge_performance_summary_cv.svg"
plt.savefig(summary_fig_path, dpi=300)
plt.close()
# print(f"[SAVED] Summary plot → {summary_fig_path}")

# -----------------------------
# Subset summary (size ≤ 250)
# -----------------------------
subset_df = cv_agg_df[cv_agg_df["size"] <= 250]

fig, axes = plt.subplots(1, 3, figsize=(16, 3), sharex=True)
colors = {"mut1": "#D55E00", "any": "#0072B2"}

for split_type, group_df in subset_df.groupby("split_type"):
    x = group_df["size"]
    for ax, metric, std, title in zip(
        axes[:3],
        ["spearman_mean", "pearson_mean", "top10_mean"],
        ["spearman_std", "pearson_std", "top10_std"],
        ["Spearman ρ", "Pearson r", "Top 10% Recall"]
    ):
        ax.plot(x, group_df[metric], marker="o", lw=1.5,
                label=split_type, color=colors[split_type])
        ax.fill_between(x,
                        group_df[metric] - group_df[std],
                        group_df[metric] + group_df[std],
                        alpha=0.2, color=colors[split_type])
        ax.set_xlabel("Training Size")
        ax.set_ylabel(title)

        # --- Baselines ---
        for name, val in baselines.items():
            if "Spearman" in title and name == "High-N Reward Model":
                y_val = highN["Spearman"]
            elif "Pearson" in title and name == "High-N Reward Model":
                y_val = highN["Pearson"]
            elif "Top" in title:
                continue
            else:
                y_val = val
            if not np.isnan(y_val):
                ax.axhline(y=y_val, color=baseline_styles[name],
                           linestyle="--", lw=1, label=f"{name} baseline")

# Legend & save
handles, labels = [], []
for ax in axes:
    h, l = ax.get_legend_handles_labels()
    handles.extend(h)
    labels.extend(l)
unique = dict(zip(labels, handles))

fig.legend(unique.values(), unique.keys(),
           loc="lower center", ncol=6, frameon=False, fontsize=10)
plt.tight_layout(rect=[0, 0.05, 1, 0.96])

subset_fig_path = f"{results_root}/{protein}_ridge_performance_summary_cv_subset250.png"
plt.savefig(subset_fig_path, dpi=300)
subset_fig_path = f"{results_root}/{protein}_ridge_performance_summary_cv_subset250.svg"
plt.savefig(subset_fig_path, dpi=300)
plt.close()




