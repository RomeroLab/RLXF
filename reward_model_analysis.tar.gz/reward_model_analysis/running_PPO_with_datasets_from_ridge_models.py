#!/usr/bin/env python
# coding: utf-8

# Import packages
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.utils.data as data_utils
from torch.utils.data import Dataset, DataLoader
import torch.distributed as dist
import pytorch_lightning as pl
from pytorch_lightning.loggers import CSVLogger
import seaborn as sns
import random
from random import choice
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.patches as mpatches
from sklearn import metrics
import os
import pickle
from transformers import AutoModelForMaskedLM, AutoTokenizer
import itertools
import copy
import logging
import sys
from torch_ema import ExponentialMovingAverage
import yaml

# import helper scripts
from utils.models.MLP import MLP
from utils.models.PPO_ESM2_w_ridge_models import (PPO_ESM2_w_ridge_models)
from utils.SFT_utils import (generate_df, generate_and_evaluate_mutants_p_sampling)
from joblib import load

################################################## hyperparameters ##################################################

# parameters to loop through
epoch_list = [2,6,10]
proteins = ['ube4b'] # 'creilov', 'gb1', 'pab1', 'ube4b', 'bgl3', 'avgfp'
Ns = [150]
target_sizes = ["any_1000", "any_500", "any_200", "any_100", "any_10", "any_1000", "any_500"]
versions = ["v0", "v1", "v2"]
num_muts_list = [5, 10]
num_mutations_list = [5, 10]
num_sequences_list = [2, 4]
model_identifier = 'esm2_t33_650M_UR50D'
sft_logger_version = 0

# run through sft models and hyperparameters
first_pretrained_paths = {}

# Track pretrained generation once per (protein, num_muts)
pretrained_done = set()

# Track SFT generation once per unique SFT model
sft_done = {}

# Skip everything outside [START_LOGGER_VERSION, END_LOGGER_VERSION]
START_LOGGER_VERSION = 72
END_LOGGER_VERSION = 84
current_logger_index = -1 # will be incremented before each PPO run

for protein in proteins:
    for target_size in target_sizes:
        for data_version in versions:
            for N in Ns:
                for num_mutations in num_mutations_list:
                    for num_sequences in num_sequences_list:
                        # Resume logic: skip early combinations
                        current_logger_index += 1
                        if current_logger_index < START_LOGGER_VERSION or current_logger_index > END_LOGGER_VERSION:
                            print(
                                f"[SKIP] logger.version {current_logger_index} not in [{START_LOGGER_VERSION}, {END_LOGGER_VERSION}]"
                            )
                            continue

                        # Parameters to update
                        if protein == "avgfp":
                            WT = "MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTLSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK"
                            num_reward_models = 10
                            # num_mutations = 6
                            high_conf_threshold = 0.9
                            cum_prob_threshold = 0.22
                        elif protein == "bgl3":
                            WT = "MVPAAQQTAMAPDAALTFPEGFLWGSATASYQIEGAAAEDGRTPSIWDTYARTPGRVRNGDTGDVATDHYHRWREDVALMAELGLGAYRFSLAWPRIQPTGRGPALQKGLDFYRRLADELLAKGIQPVATLYHWDLPQELENAGGWPERATAERFAEYAAIAADALGDRVKTWTTLNEPWCSAFLGYGSGVHAPGRTDPVAALRAAHHLNLGHGLAVQALRDRLPADAQCSVTLNIHHVRPLTDSDADADAVRRIDALANRVFTGPMLQGAYPEDLVKDTAGLTDWSFVRDGDLRLAHQKLDFLGVNYYSPTLVSEADGSGTHNSDGHGRSAHSPWPGADRVAFHQPPGETTAMGWAVDPSGLYELLRRLSSDFPALPLVITENGAAFHDYADPEGNVNDPERIAYVRDHLAAVHRAIKDGSDVRGYFLWSLLDNFEWAHGYSKRFGAVYVDYPTGTRIPKASARWYAEVARTGVLPTAGDPNSSSVDKLAAALEHHHHHH"
                            num_reward_models = 10
                            # num_mutations = 10
                            high_conf_threshold = 0.95
                            cum_prob_threshold = 0.2
                        elif protein == "creilov":
                            WT = "MAGLRHTFVVADATLPDCPLVYASEGFYAMTGYGPDEVLGHNARFLQGEGTDPKEVQKIRDAIKKGEACSVRLLNYRKDGTPFWNLLTVTPIKTPDGRVSKFVGVQVDVTSKTEGKALA"
                            num_reward_models = 100
                            # num_mutations = 15
                            high_conf_threshold = 0.9
                            cum_prob_threshold = 0.22
                        elif protein == "gb1":
                            WT = "MQYKLILNGKTLKGETTTEAVDAATAEKVFKQYANDNGVDGEWTYDDATKTFTVTE"
                            num_reward_models = 3
                            # num_mutations = 5
                            high_conf_threshold = 0.9
                            cum_prob_threshold = 0.25
                        elif protein == "pab1":
                            WT = "GNIFIKNLHPDIDNKALYDTFSVFGDILSSKIATDENGKSKGFGFVHFEEEGAAKEAIDALNGMLLNGQEIYVAP"
                            num_reward_models = 10
                            # num_mutations = 10
                            high_conf_threshold = 0.95
                            cum_prob_threshold = 0.25
                        elif protein == "ube4b":
                            WT = "IEKFKLLAEKVEEIVAKNARAEIDYSDAPDEFRDPLMDTLMTDPVRLPSGTVMDRSIILRHLLNSPTDPFNRQMLTESMLEPVPELKEQIQAWMREKQSSDH"
                            num_reward_models = 10
                            # num_mutations = 10
                            high_conf_threshold = 0.9
                            cum_prob_threshold = 0.22
                        else:
                            print('unknown protein')
                        sequence_length = len(WT)

                        # model architexture dependent
                        max_num_layers_unfreeze_each_epoch = 82 # max number of layers in ESM2 (650M) that will be trained
                        num_unfrozen_layers = 27 # initial number of layers of ESM2 unlocked
                        num_layers_unfreeze_each_epoch = 69 # numbers of layers of ESM2 to unlock each epoch until max_num_layers_unfreeze_each_epoch reached
                        epoch_threshold_to_unlock_ESM2 = 1 # interval of epochs to unlock more layers of ESM2

                        # learning rate 
                        learning_rate = 0.008656618973037239
                        lr_mult = 0.8847762860054206
                        lr_mult_factor = 1

                        # optimizer hyperparameters
                        WD = 0.009951801658490985
                        grad_clip_threshold = 6.824466143373183
                        grad_clip_threshold_factor = 1.2

                        # training hyperparameters
                        seed = 2549
                        iterations = 1

                        num_updates = max(1, int((max(epoch_list) / 100) * iterations)) # First restart occurs at 10 epochs (backprop will have occured 10*iterations times)
                        inc_batch_size = 1 # increasing batch size each epoch until max_batch_size reached
                        max_batch_size = 2 # max batch size (dependent on GPU memory)

                        # important PPO hyperparameters
                        rel_to_WT = 1 # compare designs to WT or pretrained designs
                        epsilon = 0.17377598245568548 # clipping parameter for PPO loss

                        # total reward hyperparameters
                        pairwise_hd_aver_factor = 1.0e-06 # weight for pairwise hamming distance between generated designs each epoch
                        dkl_scale_init = 1e-8 # initial weight for Dkl
                        dkl_scale = 1e-7 # weight term for Dkl after 1st epoch
                        
                        # hyparameters regarding model saving
                        filepath = f'PPO_{protein}'
                        save_filepath = f'./logs/{filepath}_{model_identifier}'
                        
                        # parameters for generating designs after alignment
                        num_designs = 100 # 1000
                        ep = max(epoch_list) - 1
                        generation_seed = 7028

                        ################################################## hyperparameters ##################################################

                        # load 2 copies of SFT model
                        sft_model = AutoModelForMaskedLM.from_pretrained(f"facebook/{model_identifier}")
                        rl_updated_model = AutoModelForMaskedLM.from_pretrained(f"facebook/{model_identifier}")
                        tokenizer = AutoTokenizer.from_pretrained(f"facebook/{model_identifier}")
                        if N == 150:
                            logger_name = f'{protein}_{target_size}_{data_version}_top{N}'
                        else:
                            logger_name = f'{protein}_{target_size}_{data_version}'
                        sft_model_path = f'./logs/{logger_name}/version_{sft_logger_version}/SFT_{model_identifier}_v0.pt'
                
                        if sft_model_path is not None:
                            # Begin PPO with 2 copies of supervised fine-tuned models
                            state_dict = torch.load(sft_model_path)
                            sft_model.load_state_dict(state_dict)
                            rl_updated_model.load_state_dict(state_dict)
                            for param in sft_model.parameters():
                                param.requires_grad = False
                            print(f'Aligning supervised fine-tuned model from {sft_model_path}')
                        else:
                            # Begin PPO with 2 copies of pretrained models
                            for param in sft_model.parameters():
                                param.requires_grad = False
                            print(f'Aligning {model_identifier} model from huggingface')

                        # load ridge regression model (low-N reward models)
                        ridge_results_dir = f"./{protein}/results/low_N_{protein}_{target_size}_{data_version}"
                        model_path = os.path.join(ridge_results_dir, f"{protein}_ridge_model.joblib")
                        meta_path  = os.path.join(ridge_results_dir, f"{protein}_ridge_metadata.yaml")

                        if not os.path.exists(model_path):
                            print(f"[WARN] Ridge model not found → {model_path}")
                            continue

                        if not os.path.exists(meta_path):
                            print(f"[WARN] Metadata file not found → {meta_path}")
                            continue

                        # Load model and evo_multiplier
                        ridge_model = load(model_path)

                        with open(meta_path, "r") as f:
                            meta = yaml.safe_load(f)

                        evo_multiplier = meta.get("evo_scale", np.sqrt(1 / 1e-5))  # default to np.sqrt(1/1e-5) if missing
                        print(f"[INFO] Loaded evo_multiplier = {evo_multiplier:.4f} from metadata")

                        low_N_reward_model = ridge_model
                        
                        # Determine if training on a GPU or CPU for reproducibility
                        if torch.cuda.is_available():
                            # Make models reproducible on GPU
                            os.environ['PYTHONHASHSEED'] = str(seed) # Set the PYTHONHASHSEED environment variable to the chosen seed to make hash-based operations predictable
                            np.random.seed(seed) # Set NumPy's random seed to ensure reproducibility of operations using NumPy's random number generator
                            random.seed(seed) # Set Python's built-in random module's seed to ensure reproducibility of random operations using Python's random functions
                            np.random.seed(seed)
                            torch.manual_seed(seed) # Set the seed for generating random numbers in PyTorch to ensure reproducibility on the CPU
                            torch.cuda.manual_seed(seed) # Set the seed for generating random numbers in PyTorch to ensure reproducibility on the GPU
                            torch.cuda.manual_seed_all(seed) # Ensure reproducibility for all GPUs by setting the seed for generating random numbers for all CUDA devices
                            torch.backends.cudnn.deterministic = True # Force cuDNN to use only deterministic convolutional algorithms (can slow down computations but guarantees reproducibility)
                            torch.backends.cudnn.benchmark = False # Prevent cuDnn from using any algorithms that are nondeterministic
                            torch.set_float32_matmul_precision('medium')
                            accelerator = "gpu"
                            num_devices = torch.cuda.device_count()  # Use all available GPUs
                            strategy = "ddp" if num_devices > 1 else None  # Use DDP if multiple GPUs
                            
                            # Determine if training via DDP or single GPU
                            if num_devices > 1:
                                from utils.models.PPO_ESM2_w_ridge_models import (ProtDataModuleESM2_DDP, ProtRepDatasetESM2_DDP)
                            else:
                                from utils.models.PPO_ESM2_w_ridge_models import (ProtDataModuleESM2, ProtRepDatasetESM2)
                                print('Running on single GPU, using alternative dataloader')
                            print(f"Accelerator: {accelerator}, Number of devices: {num_devices}, Strategy: {strategy}")
                        else:
                            # fix random seeds for reproducibility on CPU
                            torch.manual_seed(seed)
                            random.seed(seed)
                            np.random.seed(seed)
                            accelerator = "cpu"
                            max_threads = 16
                            num_threads = min(os.cpu_count(), max_threads)  # Use all available CPUs up to a maximum of 16
                            torch.set_num_threads(num_threads)  # Set the number of threads for PyTorch
                            num_devices = 1  # Use the CPU
                            strategy = None
                            from PPO_ESM2_w_ridge_models import (ProtDataModuleESM2, ProtRepDatasetESM2)
                            print(f"Accelerator: {accelerator}, Number of threads: {num_threads}, Strategy: {strategy}")
                        
                        # Align with PPO
                        logger = CSVLogger('logs', name=f"PPO_{protein}_{model_identifier}")
                        version = logger.version
                        print(f"[LOGGER] log_dir = {logger.log_dir}")

                        dm = ProtDataModuleESM2(WT, batch_size=1, seed=seed) # Loading WT to dataloader, we generate variant designs each batch so only load WT initially to models
                        model = PPO_ESM2_w_ridge_models(
                                        model_identifier, sft_model, rl_updated_model, tokenizer, sft_model_path, # model selections
                                        low_N_reward_model, evo_multiplier, protein, # aug ridge regression model parameters
                                        num_unfrozen_layers, num_layers_unfreeze_each_epoch, max_num_layers_unfreeze_each_epoch, # model dependent hyperparameters
                                        seed, epoch_list, iterations, num_updates, # training hyperparameters
                                        learning_rate, lr_mult, lr_mult_factor, # learning rate hyperparameters
                                        WD, grad_clip_threshold, grad_clip_threshold_factor, # optimizer hyperparameters
                                        WT, num_sequences, inc_batch_size, max_batch_size, num_mutations, high_conf_threshold, cum_prob_threshold, # generating design hyperparameters
                                        rel_to_WT, epsilon, # important PPO hyperparameters
                                        pairwise_hd_aver_factor, dkl_scale, dkl_scale_init, # total reward hyperparameters
                                        filepath, version, # hyparameters regarding model saving
                                        epoch_threshold_to_unlock_ESM2)
                        if strategy == "ddp":
                            trainer = pl.Trainer(
                                logger=logger,
                                max_epochs=max(epoch_list),
                                precision=16 if accelerator == "gpu" else 32,  # Mixed precision only on GPU
                                enable_progress_bar=True,
                                log_every_n_steps=1,
                                accelerator=accelerator,
                                num_nodes=1,
                                devices=num_devices,
                                strategy=strategy
                                )
                        else:
                            trainer = pl.Trainer(
                                logger=logger,
                                max_epochs=max(epoch_list),
                                precision=16 if accelerator == "gpu" else 32,  # Mixed precision only on GPU
                                enable_progress_bar=True,
                                log_every_n_steps=1,
                                accelerator=accelerator,
                                num_nodes=1,
                                devices=num_devices
                                )
                        
                        try:
                            print(f"Running PPO training: protein={protein}, target_size={target_size}, version={version}, "
                                  f"N={N}, num_sequences={num_sequences}")
                            trainer.fit(model, dm)
                            
                            # Plot metrics
                            # pt_metrics = pd.read_csv(f'{save_filepath}/version_{version}/metrics.csv')

                            log_dir = logger.log_dir
                            metrics_path = os.path.join(log_dir, "metrics.csv")
                            print(f"[INFO] Looking for metrics at: {metrics_path}")
                            if not os.path.exists(metrics_path):
                                print(f"[WARN] metrics.csv not found. Files in {log_dir}: {os.listdir(log_dir)}")
                                continue
                            pt_metrics = pd.read_csv(metrics_path)
                            
                            # Define the metrics you want to plot
                            metrics_to_plot = [
                                ['kl_divergence'],
                                ['mean_ratio_initial_iter', 'mean_ratio_final_iter'],
                                ['median_ratio_initial_iter', 'median_ratio_final_iter'],
                                ['ppo_loss_initial_iter', 'ppo_loss_final_iter'],
                                ['fitness_advantage'],
                                ['rel_WT_fitness'],
                                ['pairwise_hd_aver'],
                                ['mean_hd_from_CreiLOV'],
                                ['total_reward'],
                                ['batch_size'],
                                ['num_masks'],
                                ['max_norm']]
                            
                            # Calculate the number of rows for subplots, assuming 1 column
                            num_rows = len(metrics_to_plot)
                            
                            # Create subplots
                            fig, axs = plt.subplots(num_rows, 1, figsize=(10, num_rows * 3))  # Adjust the size as needed
                            
                            # In case there is only one metric, axs won't be an array, so we make it one for consistency
                            if num_rows == 1:
                                axs = [axs]
                            
                            # Define ratio metrics for which legends will be added
                            ratio_metrics = {'mean_ratio_initial_iter', 'mean_ratio_final_iter', 'median_ratio_initial_iter', 'median_ratio_final_iter', 'ppo_loss_initial_iter', 'ppo_loss_final_iter'}
                            
                            # Loop through each group of metrics and create a plot
                            for i, metric_group in enumerate(metrics_to_plot):
                                for metric in metric_group:
                                    if metric in pt_metrics.columns:
                                        data = pt_metrics[~pt_metrics[metric].isna()][metric]
                                        steps = pt_metrics[~pt_metrics[metric].isna()]['step']
                                        axs[i].plot(steps, data, label=metric.title())
                                
                                # Check if the current metric group contains any ratio metrics for adding legends
                                if any(metric in ratio_metrics for metric in metric_group):
                                    axs[i].legend()
                                axs[i].set_xlabel('Epoch/Step')
                                axs[i].set_ylabel(', '.join(metric_group).replace('_initial_iter', '').replace(', mean_ratio_final_iter', '').replace(', median_ratio_final_iter', '').replace(', ppo_loss_final_iter', '').title())
                                axs[i].spines['top'].set_visible(False)
                                axs[i].spines['right'].set_visible(False)
                            
                            # Adjust the layout and display the plot
                            fig.tight_layout()
                            
                            # Save figure
                            # plt.savefig(f'{save_filepath}/version_{version}/metrics_vs_steps.png')
                            plt.savefig(os.path.join(log_dir, "metrics_vs_steps.png"))
                            print('saved learning curves from aligned model')

                            # load ensemble of reward models
                            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
                            reward_models = []
                            for i in range(num_reward_models):
                                if protein == 'creilov':
                                    model_name = f"best_model_v{i}.ckpt"
                                    checkpoint_path = f"../paper_analysis/CreiLOV/reward_models/{model_name}"
                                else:
                                    model_name = f"reward_model_v{i}.ckpt"
                                    checkpoint_path = f"../paper_analysis/{protein}/reward_models/{model_name}"
                                reward_model = MLP.load_from_checkpoint(checkpoint_path)
                                for param in reward_model.parameters():
                                    param.requires_grad = False
                                reward_models.append(reward_model)

                            # Predicted WT score for plots
                            scores = []
                            for reward_model in reward_models:
                                reward_model.to(device)
                                reward_model.eval()
                                with torch.no_grad():
                                    score = reward_model.predict(WT)[0][0].cpu()  # Assuming predict returns a nested list/array
                                    scores.append(score)
                            predicted_wt_score = np.median(np.array(scores, dtype=np.float32))
                            print('predicted_wt_score:', predicted_wt_score)
                            
                            for num_muts in num_muts_list:
                                print(f"\n=== Generating variants with {num_muts} mutations ===")
                                base_path = f'{save_filepath}/version_{version}/'

                                # Keys for skipping logic
                                pretrained_key = (protein, num_muts)
                                sft_key = (protein, target_size, data_version, N, num_muts)

                                ############################################################################################################################################################
                                if pretrained_key not in pretrained_done:
                                    print(f"[RUN] Pretrained ESM2 generation for {pretrained_key}")
                                    
                                    # Load pretrained models
                                    fixed_model = AutoModelForMaskedLM.from_pretrained(f"facebook/{model_identifier}")
                                    
                                    # Generate and evaluate 1000 designs with 5 mutants
                                    fixed_mutated_seqs, fixed_scores_np = generate_and_evaluate_mutants_p_sampling(WT, reward_models, fixed_model, model_identifier, tokenizer, f'{save_filepath}/version_{version}', ep, version, num_designs, num_muts, cum_prob_threshold, high_conf_threshold, generation_seed)
                                    print(f"Finished pretrained generation ({num_muts} muts)")
                                    
                                    # Save mutants from ESM2
                                    fixed_scores_file = f"fixed_{model_identifier}_scores_{num_muts}muts.npy"
                                    fixed_seqs_file   = f"fixed_{model_identifier}_mutated_seqs_{num_muts}muts.txt"
                                    
                                    # Save files
                                    scores_path = os.path.join(base_path, fixed_scores_file)
                                    seqs_path   = os.path.join(base_path, fixed_seqs_file)
                                    np.save(scores_path, fixed_scores_np)
                                    with open(seqs_path, "w") as f:
                                        for s in fixed_mutated_seqs:
                                            f.write(s + "\n")

                                    # Record where the FIRST pretrained generation for this protein happened
                                    first_pretrained_paths[pretrained_key] = {
                                        "scores": scores_path,
                                        "seqs": seqs_path
                                    }

                                    pretrained_done.add(pretrained_key)

                                else:
                                    print(f"[SKIP] Pretrained already generated for {pretrained_key}")

                                    # Load from the ORIGINAL folder (not the current PPO version)
                                    load_info = first_pretrained_paths[pretrained_key]

                                    fixed_scores_np = np.load(load_info["scores"])
                                    with open(load_info["seqs"]) as f:
                                        fixed_mutated_seqs = f.read().splitlines()

                                ############################################################################################################################################################
                                
                                if sft_key not in sft_done:
                                    print(f"[RUN] SFT generation for {sft_key}")

                                    # Load sft model
                                    sft_model = AutoModelForMaskedLM.from_pretrained(f"facebook/{model_identifier}")
                                    state_dict = torch.load(f'{sft_model_path}')
                                    sft_model.load_state_dict(state_dict)
                                
                                    # Generate and evaluate 1000 designs with 5 mutants from both models
                                    sft_model_identifier = f"SFT_{model_identifier}"
                                    sft_mutated_seqs, sft_scores_np = generate_and_evaluate_mutants_p_sampling(WT, reward_models, sft_model, sft_model_identifier, tokenizer, f'{save_filepath}/version_{version}', ep, version, num_designs, num_muts, cum_prob_threshold, high_conf_threshold, generation_seed)
                                    print(f"Finished SFT generation ({num_muts} muts)")

                                    # Save SFT results
                                    sft_scores_file = f"sft_{model_identifier}_scores_{num_muts}muts.npy"
                                    sft_seqs_file   = f"sft_{model_identifier}_mutated_seqs_{num_muts}muts.txt"
                                    scores_path = os.path.join(base_path, sft_scores_file)
                                    seqs_path   = os.path.join(base_path, sft_seqs_file)

                                    np.save(scores_path, sft_scores_np)
                                    with open(seqs_path, "w") as f:
                                        for s in sft_mutated_seqs:
                                            f.write(s + "\n")

                                    # Record first SFT path
                                    sft_done[sft_key] = {
                                        "scores": scores_path,
                                        "seqs": seqs_path,
                                    }

                                else:
                                    print(f"[SKIP] SFT already generated for {sft_key}")

                                    # Load from ORIGINAL stored SFT path (not this PPO version)
                                    load_info = sft_done[sft_key]
                                    sft_scores_np = np.load(load_info["scores"])
                                    with open(load_info["seqs"]) as f:
                                        sft_mutated_seqs = f.read().splitlines()

                                ############################################################################################################################################################

                                # Generate DataFrames
                                df_fixed = generate_df(fixed_mutated_seqs, np.median(fixed_scores_np, axis=0), WT)
                                df_sft   = generate_df(sft_mutated_seqs,   np.median(sft_scores_np,  axis=0), WT)
                                df_fixed.to_csv(os.path.join(base_path, f"{model_identifier}_fixed_mutated_designs_scores_{num_muts}muts.csv"), index=False)
                                df_sft.to_csv(  os.path.join(base_path, f"{model_identifier}_sft_mutated_designs_scores_{num_muts}muts.csv"), index=False)

                                ############################################################################################################################################################
                                
                                for ep_save in epoch_list:
                                    ep_save_idx = ep_save - 1   # Lightning epoch indexing

                                    print(f"\n=== Loading RL model saved at epoch {ep_save} ===")

                                    ckpt_path = (
                                        f"{save_filepath}/version_{version}/"
                                        f"ema_aligned_{model_identifier}_v{version}_ep{ep_save_idx}.pt"
                                    )

                                    if not os.path.exists(ckpt_path):
                                        print(f"[WARN] RL checkpoint not found → {ckpt_path}")
                                        continue

                                    # Load RL-aligned model
                                    rl_model = AutoModelForMaskedLM.from_pretrained(f"facebook/{model_identifier}")
                                    state_dict = torch.load(ckpt_path, map_location="cpu")
                                    rl_model.load_state_dict(state_dict)

                                    rl_model_identifier = f"aligned_{model_identifier}_ep{ep_save}"
                                    print(f"[RUN] Generating RL variants for checkpoint at epoch {ep_save}")

                                    # Generate RL variants
                                    rl_mutated_seqs, rl_scores_np = generate_and_evaluate_mutants_p_sampling(
                                        WT,
                                        reward_models,
                                        rl_model,
                                        rl_model_identifier,
                                        tokenizer,
                                        f"{save_filepath}/version_{version}",
                                        ep_save_idx,
                                        version,
                                        num_designs,
                                        num_muts,
                                        cum_prob_threshold,
                                        high_conf_threshold,
                                        generation_seed,
                                    )
                                    print(f"[DONE] RL-aligned generation at epoch {ep_save}")

                                    # Save outputs
                                    rl_scores_file = f"ema_aligned_{model_identifier}_scores_{num_muts}muts_ep{ep_save}.npy"
                                    rl_seqs_file   = f"ema_aligned_{model_identifier}_mutated_seqs_{num_muts}muts_ep{ep_save}.txt"

                                    np.save(os.path.join(base_path, rl_scores_file), rl_scores_np)
                                    with open(os.path.join(base_path, rl_seqs_file), "w") as f:
                                        for s in rl_mutated_seqs:
                                            f.write(s + "\n")

                                    # Generate DataFrames
                                    df_rl    = generate_df(rl_mutated_seqs,    np.median(rl_scores_np,   axis=0), WT)
                                    df_rl.to_csv(   os.path.join(base_path, f"ema_aligned_{model_identifier}_mutated_designs_scores_{num_muts}muts_ep{ep_save}.csv"), index=False)
                                
                                    # Plot histogram
                                    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))
                                    
                                    # Plot histograms for the models
                                    sns.histplot(np.median(fixed_scores_np, axis=0), bins=25, alpha=0.4, color='grey', edgecolor='black', stat='density', ax=ax1, label='Pre-trained ESM2')
                                    sns.histplot(np.median(sft_scores_np, axis=0), bins=25, alpha=0.6, color='orange', edgecolor='black', stat='density', ax=ax1, label='SFT ESM2')
                                    sns.histplot(np.median(rl_scores_np, axis=0), bins=25, alpha=0.6, color='blue', edgecolor='black', stat='density', ax=ax1, label='Aligned ESM2')
                                    ax1.set_xlabel('Predicted Fluorescence', fontsize=12)
                                    ax1.set_ylabel('Probability Density', fontsize=12)
                                    ax1.spines['top'].set_visible(False)
                                    ax1.spines['right'].set_visible(False)
                                    ax1.axvline(predicted_wt_score, color='orange', linestyle='--', linewidth=3)
                                    ax1.axvspan(min(min(np.median(fixed_scores_np, axis=0))-0.05, min(np.median(sft_scores_np, axis=0))-0.05), predicted_wt_score, color='red', alpha=0.1, zorder=-1)
                                    ax1.axvspan(predicted_wt_score, max(max(np.median(fixed_scores_np, axis=0)) + 0.05, max(np.median(sft_scores_np, axis=0)) + 0.05), color='green', alpha=0.1, zorder=-1)
                                    ax1.legend()
                                    
                                    # Plot the cumulative density plot on the second subplot for all models
                                    sns.ecdfplot(np.median(fixed_scores_np, axis=0), stat="proportion", complementary=True, ax=ax2, color="grey", linestyle='-')
                                    sns.ecdfplot(np.median(sft_scores_np, axis=0), stat="proportion", complementary=True, ax=ax2, color="orange", linestyle='-')
                                    sns.ecdfplot(np.median(rl_scores_np, axis=0), stat="proportion", complementary=True, ax=ax2, color="blue", linestyle='-')
                                    ax2.set_xlabel('Predicted Fluorescence', fontsize=12)
                                    ax2.set_ylabel('Cumulative Density', fontsize=12)
                                    ax2.spines['top'].set_visible(False)
                                    ax2.spines['right'].set_visible(False)
                                    ax2.axvline(predicted_wt_score, color='orange', linestyle='--', linewidth=3)
                                    ax2.axvspan(min(min(np.median(fixed_scores_np, axis=0))-0.05, min(np.median(sft_scores_np, axis=0))-0.05), predicted_wt_score, color='red', alpha=0.1, zorder=-1)
                                    ax2.axvspan(predicted_wt_score, max(max(np.median(fixed_scores_np, axis=0)) + 0.05, max(np.median(sft_scores_np, axis=0)) + 0.05), color='green', alpha=0.1, label='Better than WT Fluorescence', zorder=-1)
                                    less_wt_patch = mpatches.Patch(color='red', alpha=0.8, label='Less than WT Log Fluorescence')
                                    wt_line = mpatches.Patch(color='orange', alpha=0.8, label='Mean WT Log Fluorescence')
                                    better_wt_patch = mpatches.Patch(color='green', alpha=0.8, label='Greater than WT Log Fluorescence')
                                    legend = ax2.legend(handles=[less_wt_patch, wt_line, better_wt_patch], frameon=True, edgecolor='black')
                                    plt.setp(legend.get_texts(), color='black', fontsize=10)
                                    plt.setp(legend.get_frame(), facecolor='white')
                                    plt.tight_layout()
                                    
                                    # Save the plot
                                    plot_base = f"{model_identifier}_design_scores_ep{ep_save}_{num_muts}muts"
                                    plt.savefig(os.path.join(base_path, plot_base + ".png"))
                                    print('Saved design histograms')

                        except RuntimeError as e:
                            if "CUDA out of memory" in str(e):
                                print("\n[WARNING] CUDA OOM during PPO training. "
                                      f"Skipping this configuration: protein={protein}, target_size={target_size}, "
                                      f"version={version}, N={N}, num_sequences={num_sequences}\n")
                            else:
                                print("\n[ERROR] Training failed with RuntimeError:")
                                print(e)

                            if torch.cuda.is_available():
                                torch.cuda.empty_cache()
                            continue

                        except Exception as e:
                            print("\n[ERROR] Non-CUDA exception during PPO training:")
                            print(e)
                            if torch.cuda.is_available():
                                torch.cuda.empty_cache()
                            continue


