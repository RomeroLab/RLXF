#!/usr/bin/env python
# coding: utf-8

import os, glob, yaml
import pandas as pd
from itertools import combinations, product
from joblib import load
import subprocess
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import Ridge
import numpy as np

# -----------------------------
# Configuration
# -----------------------------
protein = "ube4b" # options: ['avgfp', 'bgl3', 'creilov', 'gb1', 'pab1', 'ube4b']

num_muts = 5
topn = 40
label_col = "functional_score"
evo_col = "avg_score" # simplied from avg_score_trancepteve
data_path = f"./{protein}/data/processed_SeqFxnDataset.pkl"
split_dir = f"./{protein}/data"
results_root = f"./{protein}/results"
os.makedirs(results_root, exist_ok=True)

if protein == "avgfp":
    WT = "MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTLSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK"
elif protein == "bgl3":
    WT = "MVPAAQQTAMAPDAALTFPEGFLWGSATASYQIEGAAAEDGRTPSIWDTYARTPGRVRNGDTGDVATDHYHRWREDVALMAELGLGAYRFSLAWPRIQPTGRGPALQKGLDFYRRLADELLAKGIQPVATLYHWDLPQELENAGGWPERATAERFAEYAAIAADALGDRVKTWTTLNEPWCSAFLGYGSGVHAPGRTDPVAALRAAHHLNLGHGLAVQALRDRLPADAQCSVTLNIHHVRPLTDSDADADAVRRIDALANRVFTGPMLQGAYPEDLVKDTAGLTDWSFVRDGDLRLAHQKLDFLGVNYYSPTLVSEADGSGTHNSDGHGRSAHSPWPGADRVAFHQPPGETTAMGWAVDPSGLYELLRRLSSDFPALPLVITENGAAFHDYADPEGNVNDPERIAYVRDHLAAVHRAIKDGSDVRGYFLWSLLDNFEWAHGYSKRFGAVYVDYPTGTRIPKASARWYAEVARTGVLPTAGDPNSSSVDKLAAALEHHHHHH"
elif protein == "creilov":
    WT = "MAGLRHTFVVADATLPDCPLVYASEGFYAMTGYGPDEVLGHNARFLQGEGTDPKEVQKIRDAIKKGEACSVRLLNYRKDGTPFWNLLTVTPIKTPDGRVSKFVGVQVDVTSKTEGKALA"
elif protein == "gb1":
    WT = "MQYKLILNGKTLKGETTTEAVDAATAEKVFKQYANDNGVDGEWTYDDATKTFTVTE"
elif protein == "pab1":
    WT = "GNIFIKNLHPDIDNKALYDTFSVFGDILSSKIATDENGKSKGFGFVHFEEEGAAKEAIDALNGMLLNGQEIYVAP"
elif protein == "ube4b":
    WT = "IEKFKLLAEKVEEIVAKNARAEIDYSDAPDEFRDPLMDTLMTDPVRLPSGTVMDRSIILRHLLNSPTDPFNRQMLTESMLEPVPELKEQIQAWMREKQSSDH"
else:
    print('unknown protein')

# -----------------------------
# Helper: sequence splitting
# -----------------------------
def split_sequence(df, seq_col="sequence"):
    seq_df = df[seq_col].apply(list).apply(pd.Series)
    seq_df.columns = [f"pos_{i}" for i in range(seq_df.shape[1])]
    expanded_df = pd.concat([df.drop(columns=[seq_col]), seq_df], axis=1)
    return expanded_df, seq_df.shape[1]

# -----------------------------
# Filter split paths by size (100, 1000, or 10000) and version number (v0, v1, v2)
# -----------------------------
split_paths = sorted(glob.glob(f"{split_dir}/low_N_{protein}_*.pkl"))
target_sizes = ["any_10000"] # "any_10", "any_100", "any_200", "any_500", "any_1000", "any_10000"
versions = ["v0"] # "v0", "v1", "v2"

filtered_split_paths = [
    p for p in split_paths
    if any(f"_{size}_" in os.path.basename(p) for size in target_sizes)
    and any(f"_{v}." in os.path.basename(p) for v in versions)
]

print(f"[INFO] Found {len(filtered_split_paths)} split files for {protein}")

# for split path, find top unique 50 variants with num_muts using ridge regression model
for split_path in filtered_split_paths:
    print(split_path)
    split_name = os.path.basename(split_path)
    results_root = f"./{protein}/results"
    results_dir = f"{results_root}/{split_name.replace('.pkl', '')}"

    # Construct path to the saved CSV
    aa_weights_path = f"{results_dir}/{protein}_ridge_aa_weights_long.csv"
    aa_weight_df = pd.read_csv(aa_weights_path)

    # --- Filter for positive non-WT coefficients ---
    positive_df = aa_weight_df[aa_weight_df["weight"] > 0].copy()
    positive_df["WT_residue"] = positive_df["position"].apply(
        lambda i: WT[i - 1] if i - 1 < len(WT) else None
    )
    non_wt_positive_df = positive_df[
        positive_df["amino_acid"] != positive_df["WT_residue"]
    ].copy()

    # --- Group by position first, filtering out stop codons per position ---
    pos_to_mut_df = (
        non_wt_positive_df[non_wt_positive_df["amino_acid"] != "*"]
        .groupby("position", group_keys=False)
        .apply(lambda g: g.sort_values("weight", ascending=False))
    )

    # --- Sort by coefficient magnitude globally and keep top 15 ---
    top_df = pos_to_mut_df.sort_values("weight", ascending=False).head(topn)
    print(f"[INFO] Using top {topn} non-WT residues out of {len(pos_to_mut_df)} total.")
    pos_to_mut = (
        top_df.groupby("position")["amino_acid"]
        .apply(list)
        .to_dict()
    )

    # --- Generate all combinations of positions ---
    variant_records = []
    for pos_combo in combinations(pos_to_mut.keys(), num_muts):
        aa_combos = product(*[pos_to_mut[p] for p in pos_combo])

        for aas in aa_combos:
            # skip if any amino acid in this combo is a stop codon (safety check)
            if "*" in aas:
                continue

            seq_list = list(WT)
            mut_labels = []
            for pos, aa in zip(pos_combo, aas):
                wt_aa = WT[pos - 1]  # 1-indexed
                seq_list[pos - 1] = aa
                mut_labels.append(f"{wt_aa}{pos}{aa}")

            variant_seq = "".join(seq_list)
            mutant = ":".join(mut_labels)

            variant_records.append({
                "mutant": mutant,
                "mutated_sequence": variant_seq
            })

    variants_df = pd.DataFrame(variant_records)
    print(f"[INFO] Generated {len(variants_df)} variants with {num_muts} mutations (no stop codons).")

    # --- Save for TranceptEVE ---
    variants_path = f"{results_dir}/{protein}_variants_from_ridge_weights_scores.csv"
    os.makedirs(os.path.dirname(variants_path), exist_ok=True)
    variants_df[["mutated_sequence", "mutant"]].to_csv(variants_path, index=False)
    print(f"[SAVED] variant file for TranceptEVE scoring → {variants_path}")

    # --- Write TranceptEVE scoring script ---
    sh_path = f"{results_dir}/score_trancepteve_{protein}.sh"
    with open(sh_path, "w") as f:
        f.write(f"""#!/bin/bash
set -e

protein="{protein}"
theta=0.2
checkpoint="../../Tranception/Tranception_Small"
msa_base="../../Creating_msa_for_RLXF_revisions/config"
weights_base="../../training_VAEs_for_RLXF_revisions/data/weights"
output_base="{results_dir}"

inference_time_retrieval_type="TranceptEVE"
EVE_num_samples_log_proba=200000
scoring_window="optimal"
EVE_model_folder="../../training_VAEs_for_RLXF_revisions/results/VAE_parameters/{protein}_{protein}_final"
EVE_model_parameters_location='../../training_VAEs_for_RLXF_revisions/EVE/default_model_params.json'
random_seeds=(0)
EVE_seeds_str="${{random_seeds[@]}}"

echo "[INFO] Scoring $protein variants with TranceptEVE..."

wt_seq=$(grep -v ">" ${{msa_base}}/${{protein}}.fa | tr -d '\n')
len=${{#wt_seq}}

python -u ../../Tranception/score_trancepteve.py \
    --checkpoint $checkpoint \
    --target_seq $wt_seq \
    --DMS_file_name {protein}_variants_from_ridge_weights_scores.csv \
    --MSA_filename $protein.a2m \
    --MSA_weight_file_name {protein}_theta_${{theta}}.npy \
    --MSA_start 1 \
    --MSA_end $len \
    --MSA_threshold_sequence_frac_gaps 1.0 \
    --MSA_threshold_focus_cols_frac_gaps 1.0 \
    --DMS_data_folder "{results_dir}/" \
    --output_scores_folder $output_base/{protein}_scores \
    --scoring_window $scoring_window \
    --inference_time_retrieval_type $inference_time_retrieval_type \
    --MSA_folder ${{msa_base}}/out/{protein}/align \
    --MSA_weights_folder $weights_base \
    --EVE_model_folder $EVE_model_folder \
    --EVE_num_samples_log_proba $EVE_num_samples_log_proba \
    --EVE_model_parameters_location $EVE_model_parameters_location \
    --EVE_seeds $EVE_seeds_str \
    --EVE_recalibrate_probas

echo "[DONE] Finished scoring {protein} with TranceptEVE"
""")

    os.chmod(sh_path, 0o755)
    print(f"[SAVED] TranceptEVE script → {sh_path}")
    
    # -----------------------------
    # Run TranceptEVE scoring
    # -----------------------------
    print(f"[RUNNING] Executing {sh_path} ...")
    try:
        subprocess.run(["bash", sh_path], check=True)
        print(f"[DONE] Finished TranceptEVE scoring → {results_dir}")
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] TranceptEVE scoring failed for {protein}.\nReturn code: {e.returncode}")
        continue

    # -----------------------------
    # Merge TranceptEVE scores with variants
    # -----------------------------
    trancept_path = f"{results_dir}/{protein}_scores/{protein}_variants_from_ridge_weights_scores.csv"
    if os.path.exists(trancept_path):
        trancept_df = pd.read_csv(trancept_path)
        merged_df = variants_df.merge(trancept_df, on=["mutated_sequence", "mutant"], how="left")
        merged_df.to_csv(f"{results_dir}/{protein}_variants_with_TranceptEVE.csv", index=False)
        print(f"[SAVED] Merged variants + TranceptEVE scores → {results_dir}")
    else:
        print(f"[WARN] TranceptEVE output not found → {trancept_path}")
        continue

    # -----------------------------
    # Re-score with Ridge regression model
    # -----------------------------
    model_path = f"{results_dir}/{protein}_ridge_model.joblib"
    meta_path = f"{results_dir}/{protein}_ridge_metadata.yaml"

    if not os.path.exists(model_path):
        print(f"[WARN] Ridge model not found → {model_path}")
        continue
    if not os.path.exists(meta_path):
        print(f"[WARN] Metadata file not found → {meta_path}")
        continue

    # --- Load ridge model ---
    model = load(model_path)

    # --- Load metadata for evo_multiplier ---
    with open(meta_path, "r") as f:
        meta = yaml.safe_load(f)
    evo_multiplier = meta.get("evo_scale", np.sqrt(1/1e-5))  # default to np.sqrt(1/1e-5) if missing
    print(f"[INFO] Loaded evo_multiplier = {evo_multiplier:.4f} from metadata")

    # --- Prepare sequence dataframe ---
    seq_df, seq_len = split_sequence(merged_df.rename(columns={"mutated_sequence": "sequence"}))

    # --- Apply scaling ---
    seq_df["evo_scaled"] = seq_df[evo_col] * evo_multiplier

    # --- Ridge scoring ---
    ridge_scores = model.predict(seq_df)
    merged_df["ridge_score"] = ridge_scores
    merged_df.to_csv(f"{results_dir}/{protein}_variants_with_TranceptEVE.csv", index=False)

    # -----------------------------
    # Select top 50 by ridge score
    # -----------------------------
    top50_df = merged_df.nlargest(50, "ridge_score")
    top50_df = top50_df.rename(columns={"mutated_sequence": "sequence"})
    top50_csv = f"{results_dir}/{protein}_top50_variants.csv"
    top50_pkl = f"{results_dir}/{protein}_top50_variants.pkl"
    top50_df.to_csv(top50_csv, index=False)
    top50_df.to_pickle(top50_pkl)  # preserves dtypes/index; fast reload with pd.read_pickle

    print(f"[SAVED] Top 50 ridge-predicted variants → {top50_csv}")
    print(f"[SAVED] Pickle → {top50_pkl}")





